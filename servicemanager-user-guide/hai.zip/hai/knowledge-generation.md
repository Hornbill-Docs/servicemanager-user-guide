---
layout: article-toc
---
# Knowledge Generation

Prompt based knowedge article generation from within a new or existing knowedge article

either start from scratch with a prompt ... Write a guide on changing the printer ink in Epson *** printers

or use a prompt to add to an existing article... add a paragraph explaining how to do this using terminal access rathern than the GUI

Highlighted text will be replaced when a prompt is accepted if nothing is highlighted the prompt output will be appended to the end of the existing text.

Available in resolved requests, using the request details a knowedge article can be created and submitted as draft.