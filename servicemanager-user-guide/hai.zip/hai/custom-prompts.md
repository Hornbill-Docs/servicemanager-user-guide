---
layout: article-toc
---
# Custom Prompts

Text areas withing a request have a new set of prompts available:
* Update request timeline
* Resolve Request
* Email Update
* Bulk Update request from the request list view
* Knowledge

Updated Prompts Include:
* Ask HAi - General open ended prompt for asking generative ai to write something helpful similar to the existing '''Elaborate''' feature in AI Assist.
* Change Tone
    * Aologetic
    * Professional
    * Freindly
    * Technical
* Improve Text - Wont change bulk of the text but will correct spelling grammer and imrove teh readability.
* Shortern Text - Make more concice 
* Listify - Return a series or actions or items in list form rather than blocks of text.

Output format
The updated prompts return the output format of the area they are in, for example Update Timeline and Resolve request return with Wiki markup formating but the Email update and knowledge will output HTML.