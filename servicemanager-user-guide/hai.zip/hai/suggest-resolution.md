---
layout: article-toc
---
# Suggest Resolution

Available eiter from the timeline of a request where a specific response can be selected (Top level not comments) and used to suggest a user frindly resotuion to the end user, an example of this would be a heavily techinicaly response from third line that needs to be rephrased for a user. 

Alternatively directly in the resolution feild a prompt can be used and based on the initial request and timeline generative ai will produce a user fruindly response. 