## Access
To enable any of the HAi capabilitys of Hornbill Service Manager, your User Account must have one of the following roles associated, all features are disabled by default and must each be enabled before they can be used by an enduser.

|Role|Description|
|-|-|
|Service Desk Admin|This role is for a Service Desk Administrator. This includes, an elevated visibility to Requests and associated actions, the ability to configure Service Manager features via the Administration Tool and the option to restart a failed BPM within a Request.|

Additionaly any user with the application right, rightA.administerServiceDesk can enable HAi features in Hornbill Service Manager.

## Enable Features
* Ensure you are logged into hornbill with the relevant access role.
* Click on the gear in the lower left of the screen.
* Change the dropdown from '''My Personal Settings''' to '''Service Manager'''.
* Click on HAi Under Asministration in the left hand menu.
* Enable the required feature.

<img src="/_books/servicemanager-user-guide/images/hai_config.png" alt="Hornbill Ai Configuration" ></img>

## Data 
By enabaling any of these optional features you are agreeing to the Terms and Conditions set out in the [HAi Supplemental Terms](https://www.hornbill.com/hai-terms-use).
Data from prompts and underlying request data is passed to open ai, this data includes:
* User text as part of the prompt
* Request Summary
* Request Description
* Name of the user who raised the request
* Name of the analyst currently assigned to the request
* Timeline of actions against the request

## OpenAI Usage
Usage of the OpenAI API's goes through an API Key provided by hornbill, currently their are no usage limites outside the limits provided by OpenAI. It is possible to override the API to use one of your oranisations choosing by overriding the system setting: '''integration.openai.apiKey'''

Further details on this here: https://docs.hornbill.com/esp-fundamentals/productivity/ai-assist