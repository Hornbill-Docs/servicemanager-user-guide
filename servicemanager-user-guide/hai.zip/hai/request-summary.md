---
layout: article-toc
---
# Request Summary

Generate a helpful summary of the initial request, actions by the end user who raised the request that have been updated via email or selfservice and a list of actions perfomed by analysts. 

Output format return as Wiki, saved with details of who and when the last generated text was created by.

User editiable before saving.