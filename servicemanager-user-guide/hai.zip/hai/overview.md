---
layout: article-toc
---
# Overview
<img src="/_books/servicemanager-user-guide/images/hai_logo.png" alt="Hornbill Ai" width="100"></img>

HAi is an Artificial intelligence (AI) tool to help make your users life at work easier and more effecient. 

## Access
Any user with rights to each area of Service Manager where a HAi feature is present has rights to interact with the underlying features, no additional rights or roles are needed for the end user.

## Features
* **[Request Summary](/hdoc-guide/servicemanager-user-guide/hai/request-summary)**<br>
Quickly summarise a request, customer and analyst actions using Generative AI.
* **[Assist](/hdoc-guide/servicemanager-user-guide/hai/custom-prompts)**<br>
Improve agent efficiency with updated HAi Assist prompts and more widley available in Service Manager. 
* **[Knowledge Generation](/hdoc-guide/servicemanager-user-guide/hai/knowledge-generation)**<br>
Using Generative AI to create Knowledge Articles from scratch and at point of request resolution. 
* **[Smart Resolution](/hdoc-guide/servicemanager-user-guide/hai/suggest-resolution)**<br>
Use Generative AI to craft user freindly resolutions from more techincal responses. 